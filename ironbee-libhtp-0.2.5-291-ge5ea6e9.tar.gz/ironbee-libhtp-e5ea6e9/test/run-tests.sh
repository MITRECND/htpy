#!/bin/sh
./main ${srcdir}/files
